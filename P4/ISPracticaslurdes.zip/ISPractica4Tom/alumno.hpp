/*! 
   \file alumno.hpp
   \brief Fichero de la clase Alumno
   \author Tomas Jesus Bolaños Campos
*/
#ifndef _ALUMNO_HPP_
#define _ALUMNO_HPP_
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>

using namespace std;
using std::istream;
using std::ostream;
namespace is {
//!  Definición de la clase Alumno
class Alumno{
  //! \name Atributos privados de la clase Alumno
   private:
   	string _apellidos;
   	string _dni;
   	string _nombre;
   	int _tlf;
   	string _correo;
   	string _domicilio;
   	string _fechaNacimiento;
   	int _cursoAlto;
   	int _equipo;
   	int _lider;
   //! \name Funciones o métodos publicos de la clase Alumno
	public:
	Alumno(){
		setDni("Vacio");
		setNombre("No-Asignad0");
		setApellidos("No-asignado");
	}
	
	//! \name Observadores: funciones de consulta de Alumno
	/*! 
		\brief   Funcion que devuelve el apellido de un alumno
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Apellido del alumno (tipo string)
		\pre     Ninguna
		\post    Ninguna
	*/
	inline string getApellidos() const{
		return _apellidos;
	}
	/*! 
		\brief   Funcion que devuelve el dni de un alumno
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Dni del alumno (tipo string)
		\pre     Ninguna
		\post    Ninguna
	*/
	inline string getDni() const{
		return _dni;
	}
	/*! 
		\brief   Funcion que devuelve el nombre de un alumno
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Nombre del alumno (tipo string)
		\pre     Ninguna
		\post    Ninguna
	*/
	inline string getNombre() const{
		return _nombre;
	}
	/*! 
		\brief   Funcion que devuelve el telefono de un alumno
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Telefono del alumno (tipo int)
		\pre     Ninguna
		\post    Ninguna
	*/
	inline int getTelefono() const{
		return _tlf;
	}
	/*! 
		\brief   Funcion que devuelve el correo de un alumno
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Correo del alumno (tipo string)
		\pre     Ninguna
		\post    Ninguna
	*/
	inline string getCorreo() const{
		return _correo;
	}
	/*! 
		\brief   Funcion que devuelve el domicilio de un alumno
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Domicilio del alumno (tipo string)
		\pre     Ninguna
		\post    Ninguna
	*/
	inline string getDomicilio() const{
		return _domicilio;
	}
	/*! 
		\brief   Funcion que devuelve la fecha de nacimiento de un alumno
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Fecha de nacimiento del alumno (tipo string)
		\pre     Ninguna
		\post    Ninguna
	*/
	inline string getFechanacimiento() const{
		return _fechaNacimiento;
	}
	/*! 
		\brief   Funcion que devuelve el curso mas alt en el que esta matriculado un alumno
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Curso mas alto en el que esta matriculado el alumno (tipo int)
		\pre     Ninguna
		\post    Ninguna
	*/
	inline int getCursoAlto() const{
		return _cursoAlto;
	}
	/*! 
		\brief   Funcion que devuelve el equipo al que pertenece un alumno
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Equipo del alumno (tipo int)
		\pre     Ninguna
		\post    Ninguna
	*/
	inline int getEquipo() const{
		return _equipo;
	}
	/*! 
		\brief   Funcion que devuelve si el alumno es lider o no
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Numero para saber si es lider o no un alumno (tipo int)
		\pre     Ninguna
		\post    Ninguna
	*/
	inline int getLider() const{
		return _lider;
	}
	//! \name Funciones de modificacion de vertice
	
	/*! 
		\brief Funcion que asigna un valor "apellidos" al atributo apellido del alumno
		\note  Funcion inline
		\param apellidos: nuevo valor de apellidos para alumno (tipo string)
		\pre   Ninguna
		\post  (this->getApellidos() == apellidos)
	*/
	inline void setApellidos(string apellidos){
		_apellidos = apellidos;
		#ifndef NDEBUG
		assert( this->getApellidos() == apellidos ); 
		#endif
	}
	/*! 
		\brief Funcion que asigna un valor "dni" al atributo dni del alumno
		\note  Funcion inline
		\param dni: nuevo valor de dni para alumno (tipo string)
		\pre   Ninguna
		\post  (this->getDni() == dni)
	*/
	inline void setDni(string dni){
		_dni = dni;
		#ifndef NDEBUG
		assert( this->getDni() == dni ); 
		#endif
	}
	/*! 
		\brief Funcion que asigna un valor "nombre" al atributo nombre del alumno
		\note  Funcion inline
		\param nombre: nuevo valor de nombre para alumno (tipo string)
		\pre   Ninguna
		\post  (this->getNombre() == nombre)
	*/
	inline void setNombre(string nombre){
		_nombre = nombre;
		#ifndef NDEBUG
		assert( this->getNombre() == nombre ); 
		#endif
	}
	/*! 
		\brief Funcion que asigna un valor "tlf" al atributo telefono del alumno
		\note  Funcion inline
		\param tlf: nuevo valor de telefono para alumno (tipo int)
		\pre   Ninguna
		\post  (this->getNombre() == nombre)
	*/
	inline void setTelefono(int tlf){
		_tlf = tlf;
		#ifndef NDEBUG
		assert( this->getTelefono() == tlf ); 
		#endif
	}
	/*! 
		\brief Funcion que asigna un valor "correo" al atributo correo del alumno
		\note  Funcion inline
		\param correo: nuevo valor de correo para alumno (tipo string)
		\pre   Ninguna
		\post  (this->getCorreo() == correo)
	*/
	inline void setCorreo(string correo){
		_correo = correo;
		#ifndef NDEBUG
		assert( this->getCorreo() == correo ); 
		#endif
	}
	/*! 
		\brief Funcion que asigna un valor "domicilio" al atributo domicilio del alumno
		\note  Funcion inline
		\param domicilio: nuevo valor de domicilio para alumno (tipo string)
		\pre   Ninguna
		\post  (this->getDomicilio() == domicilio)
	*/
	inline void setDomicilio(string domicilio){
		_domicilio = domicilio;
		#ifndef NDEBUG
		assert( this->getDomicilio() == domicilio ); 
		#endif
	}
	/*! 
		\brief Funcion que asigna un valor "fecha" al atributo fecha nacimiento del alumno
		\note  Funcion inline
		\param fecha: nuevo valor de fecha nacimiento para alumno (tipo string)
		\pre   Ninguna
		\post  (this->getFechanacimiento() == fecha)
	*/
	inline void setFechanacimiento(string fecha){
		_fechaNacimiento = fecha;
		#ifndef NDEBUG
		assert( this->getFechanacimiento() == fecha ); 
		#endif
	}
	/*! 
		\brief Funcion que asigna un valor "curso" al atributo curso mas alto del alumno
		\note  Funcion inline
		\param curso: nuevo valor de curso mas alto para alumno (tipo int)
		\pre   Ninguna
		\post  (this->getCursoAlto() == curso)
	*/
	inline void setCursoAlto(int curso){
		_cursoAlto = curso;
		#ifndef NDEBUG
		assert( this->getCursoAlto() == curso ); 
		#endif
	}
	/*! 
		\brief Funcion que asigna un valor "equipo" al atributo equipo del alumno
		\note  Funcion inline
		\param equipo: nuevo valor de equipo para alumno (tipo int)
		\pre   Ninguna
		\post  (this->getCursoAlto() == curso)
	*/
	inline void setEquipo(int equipo){
		_equipo = equipo;
		#ifndef NDEBUG
		assert( this->getEquipo() == equipo ); 
		#endif
	}
	/*! 
		\brief Funcion que asigna un valor "lider" al atributo lider del alumno
		\note  Funcion inline
		\param lider: nuevo valor de lider para alumno (tipo int)
		\pre   Ninguna
		\post  (this->getCursoAlto() == curso)
	*/
	inline void setLider(int lider){
		_lider = lider;
		#ifndef NDEBUG
		assert( this->getLider() == lider ); 
		#endif
	}
	//! \name Funciones lectura y escritura de la clase Alumno
	/*! 
		\brief   Asigna a un alumno los atributos por teclado
		\warning Se deben teclear numeros
		\pre     Ninguna
	*/
	void leerAlumno();
	/*! 
		\brief   Escribe por pantalla los atributos de un alumno
		\pre     Ninguna
	*/
	void escribirAlumno();
    //! \name Operadores
	/*! 
		\brief     Operador de asignacion: operador que "copia" un Alumno en otro
		\attention Se sobrecarga el operador de asignacion "="
		\note      Funcion inline
		\warning   Se requiere que las funciones de acceso get tengan el modificador const
		\param     a: objeto de tipo alumno pasado como referencia constante
		\pre       El alumno a debe ser diferente del alumno actual
		\post      El alumno actual debe ser igual al alumno pasado como argumento
	*/
	inline Alumno & operator=(is::Alumno const &a){
//Se comprueba que es distinto
		if (this != &a){
			setApellidos(a.getApellidos());
			setDni(a.getDni());
			setNombre(a.getNombre());
			setTelefono(a.getTelefono());
			setCorreo(a.getCorreo());
			setDomicilio(a.getDomicilio());
			setFechanacimiento(a.getFechanacimiento());
			setCursoAlto(a.getCursoAlto());
			setEquipo(a.getEquipo());
			setLider(a.getLider());
			#ifndef NDEBUG
				assert( this->getApellidos() == a.getApellidos() );
				assert( this->getDni() == a.getDni() );
				assert( this->getNombre() == a.getNombre() );
				assert( this->getTelefono() == a.getTelefono() );
				assert( this->getCorreo() == a.getCorreo() );
				assert( this->getDomicilio() == a.getDomicilio() );
				assert( this->getFechanacimiento() == a.getFechanacimiento() );
				assert( this->getCursoAlto() == a.getCursoAlto() );
				assert( this->getEquipo() == a.getEquipo() );
				assert( this->getLider() == a.getLider() );    
			#endif
		}
		return *this;
	}
	/*! 
		\brief     Operador de igualdad: compara si un alumno es igual a otro
		\attention Se sobrecarga el operador de igualdad "=="
		\note      Funcion inline
		\param     a: objeto de tipo alumno pasado como referencia constante
		\pre       Ninguna
		\post      Ninguna
	*/
	inline bool operator == (is::Alumno const &a) const{
    	if(this->getApellidos() == a.getApellidos() and this->getDni() == a.getDni() and this->getNombre() == a.getNombre() )
    		return true;
    return false;
	}
	/*! 
		\brief     Operador de desigualdad: compara si un alumno es diferente a otro
		\attention Se sobrecarga el operador de desigualdad "!="
		\note      Funcion inline
		\param     a: objeto de tipo alumno pasado como referencia constante
		\pre       Ninguna
		\post      Ninguna
	*/
	inline bool operator != (is::Alumno const &a) const{
    	if(this->getApellidos() == a.getApellidos() and this->getDni() == a.getDni() and this->getNombre() == a.getNombre() )
    		return false;
    return true;
	}
	
}; // Fin de la definicion de la clase Alumno


} // \brief Fin de namespace is.
//  _ALUMNO_HPP_
#endif
