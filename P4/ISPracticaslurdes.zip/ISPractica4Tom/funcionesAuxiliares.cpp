/*!	
	\file  funcionesAuxiliares.cpp
	\brief Definición de las funciones auxiliares
	\author Tomas Jesus Bolaños Campos
	\date  29/10/2018
*/

#include <fstream>
#include <iostream>
#include <string>
#include <cctype>
#include <unistd.h>
#include <string.h>
#include <vector>
#include "funcionesAuxiliares.hpp"
#include "macros.hpp"


int is::menu()
{

	int opcion, posicion = 8;

	std::cout << CLEAR_SCREEN;


	PLACE(5,6);
	std::cout << BGREEN;
	std::cout << "Programa principial | Opciones del menú   ";
	std::cout << RESET;

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[1] " << IBLUE << "Cargar un fichero de Alumnos";

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[2] " << IBLUE << "Guardar un fichero de Alumnos";

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[3] " << IBLUE << "Añadir un alumno";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[4] " << IBLUE << "Modificar alumno";

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[5] " << IBLUE << "Mostrar a todos los alumnos";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[6] " << IBLUE << "Mostrar un solo alumno";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[7] " << IBLUE << "Borrar a un alumno";

	PLACE(posicion++,6);
	std::cout << BIGREEN << "[0] " << IGREEN << "Salir";

	PLACE(posicion++,15);
	std::cout << IYELLOW;
	std::cout << "Opción: ";
	std::cout << RESET;

	// Se lee el número de opción
	std::cin >> opcion;

    // Se elimina el salto de línea del flujo de entrada
    std::cin.ignore();

    std::cout << CLEAR_SCREEN;

	return opcion;
}

void is::MostrarTodos(is::Agenda a)
{
	if(a.isEmpty() == true)
	{
		std::cout << BIRED << "La Agenda de Alumnos se encientra vacía";
	}else{
		a.mostrarTodos();
		std::cout << BIBLUE << "---- Finalizado con exito ----";
	}

}

void is::MostrarUno(is::Agenda a)
{
	int n,n1;
	string cadena;
	char cadena1[] = "Vacio";
	int  res;
	vector <Alumno> al;
	is::Alumno alumno;
	if(a.isEmpty() == true)
	{
		std::cout << BIRED << "La Agenda de Alumnos se encientra vacía";
	}else{
		std::cout << BIBLUE << "¿Deseas buscar un alumno o un grupo?"<<std::endl<<"( 1 -Alumno  2 -Grupo)"<<std::endl;
		cin>> n;
		if(n == 1)
		{
			std::cout << BIGREEN << "¿Deseas buscar por Apellidos o Dni?"<<std::endl<<"( 1 -Apellidos  2 -Dni)"<<std::endl;
			cin>> n1;
			if(n1 == 1)
			{
				std::cout << BIBLUE << "Introduzca los Apellidos"<<std::endl;
				getline(cin, cadena, '\n');
				//cin.ignore;
				do{
					alumno = a.buscarAlumnoApellidos(cadena);
					res = strcmp(cadena1,alumno.getDni().c_str());
					if(res != 0){
						al.push_back(alumno);
						a.borrarAlumno(alumno);
					}
				}while(res != 0);
					if(al.empty()==true){
						std::cout<<BIRED<<"No se ha encontrado ningun alumno con esos apellidos"<<std::endl;
					}else{
						for(unsigned int i=0;i<al.size();i++){
							al[i].escribirAlumno();
						}
					}
			}else if(n1 == 2)
			{
				//BuscarDni
				std::cout<< BIBLUE<<"Introduzca el Dni"<<std::endl;
					getline(cin,cadena, '\n');
					do{
						alumno=a.buscarAlumnoDNI(cadena);
						res = strcmp(cadena1,alumno.getDni().c_str());
						if(res != 0){
							al.push_back(alumno);
							a.borrarAlumno(alumno);
						}
					}while(res !=0);
						if(al.empty()==true){
							std::cout<<BIRED<< "No se ha encontrado ningun alumno con ese DNI"<<std::endl;
						}else{
							for(unsigned int i=0;i<al.size();i++){
								al[i].escribirAlumno();
							}
						}
			}else{
				std::cout << BIRED << "La proxima vez introduzca una opcion valida";
			}
		}else if(n == 2)
		{
			std::cout<<BIBLUE<< "¿Desea buscar un grupo en concreto o el grupo de un alumno?"<<std::endl<<"(1 -Alumno  2 -Grupo)"<<std::endl;
			cin>>n1;
			if(n1==1){//BUSCA ALUMNO
				cout<<BIGREEN<<"Introduzca el DNI"<<std::endl;
				getline(cin,cadena,'\n');
				do{
					alumno=a.buscarAlumnoDNI(cadena);
					res = strcmp(cadena1,alumno.getDni().c_str());
					if(res!=0){
						//FUNCIONES GRUPO
					}
				}while(res!=0);
			
			}else if(n1==2){//BUSCA AL GRUPO
				
			}else{
				std::cout << BIRED << "La proxima vez introduzca una opcion valida capullo";
			}
		}else
		{
			std::cout << BIRED << "La proxima vez introduzca una opcion valida capullo";
		}
		
	}

}

void is::Borrar(is::Agenda &a)
{
	if(a.isEmpty() == true)
	{
		std::cout << BIRED << "La Agenda de Alumnos se encientra vacía";
	}else{
		//a.borrarAlumno();
		std::cout << BIBLUE << "---- Finalizado con exito ----";
	}

}

void is::Modificar(is::Agenda &a)
{
	if(a.isEmpty() == true)
	{
		std::cout << BIRED << "La Agenda de Alumnos se encientra vacía";
	}else{
		//a.borrarAlumno();
		std::cout << BIBLUE << "---- Finalizado con exito ----";
	}

}

void is::Anadir(is::Agenda &a)
{
	is::Alumno alumno,alumno2;
	if(a.getAlumnos() == 150)
	{
		std::cout << BIRED << "La Agenda de Alumnos se encientra llena" << std::endl;
		std::cout << BIRED << "Debe vaciarla si quiere añadir de nuevo";
	}else{
		std::cout << BIBLUE << "Introduzca los datos necesarios:" << std::endl;
		alumno.leerAlumno();
		usleep(200);
		//Comprobacion de DNI
		a.anadirAlumno(alumno);
		usleep(100);
		std::cout << BIBLUE << "---- Finalizado con exito ----";
	}
	
}

// Fin de _FuncionesAuxiliares_CPP_
