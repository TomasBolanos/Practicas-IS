/*!
	\file principalGrafo.cpp
	\brief Programa principal de la practica 4 de IS
	\author Tomás Jesús Bolaños Campos
	\date 29/10/2018
	\version 1.0
*/
#include <iostream>
#include <string>
#include "alumno.hpp"
#include "profe.hpp"
#include "funcionesAuxiliares.hpp"
#include "macros.hpp"
/*! 
	\brief   Programa principal de la práctica 4
	\return  int
*/
int main(){
	//is::Profesor p;
	is::Agenda a;
	std::string n;
	int opcion;
	do{
		opcion = is::menu();
		std::cout << CLEAR_SCREEN;
		PLACE(3,1);
		switch(opcion){
			case 0: 
					std::cout << INVERSE;
					std::cout << "Fin del programa" << std::endl;
					std::cout << RESET;
			break;
		   ///////////////////////////////////////////////////////////////////
			case 1: 
					std::cout << BIBLUE;
					std::cout << "[1] Cargar un fichero de Alumnos" << std::endl;
					std::cout << BIGREEN;
					
					//is::cargarFich(p);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 2: 
					std::cout << BIBLUE;
					std::cout << "[2] Guardar un fichero de Alumnos" << std::endl;
					
					//is::guardarFich(p);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 3: 
					std::cout << BIBLUE;
					std::cout << "[3] Añadir un alumno" << std::endl;
					is::Anadir(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 4: 
					std::cout << BIBLUE;
					std::cout << "[4] Modificar alumno" << std::endl;
					is::Modificar(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 5: 
					std::cout << BIBLUE;
					std::cout << "[5] Mostrar a todos los alumnos" << std::endl;
					is::MostrarTodos(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 6: 
					std::cout << BIBLUE;
					std::cout << "[6] Mostrar un solo alumno" << std::endl;
					is::MostrarUno(a);
					
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 7: 
					std::cout << BIBLUE;
					std::cout << "[7] Borrar a un alumno" << std::endl;
					is::Borrar(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			default:
				std::cout << BIRED;
				std::cout << "Opción incorrecta ";
				std::cout << RESET;
				std::cout << "--> ";
			  	std::cout << ONIRED;
				std::cout << opcion << std::endl;
				std::cout << RESET;
     }
    if (opcion !=0)
    {
		PLACE(25,1);
		std::cout << "Pulse ";
		std::cout << BIGREEN;
		std::cout << "ENTER";
		std::cout << RESET;
		std::cout << " para mostrar el ";
		std::cout << INVERSE;
		std::cout << "menú"; 
		std::cout << RESET;
		std::cin.ignore();
		std::cout << CLEAR_SCREEN;
    }
	  }while(opcion!=0);
	return 0;
}
