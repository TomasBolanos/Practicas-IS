/*! 
   \file profe.hpp
   \brief Fichero de la clase Profesor
   \author Tomas Jesus Bolaños Campos
*/
#ifndef _PROFE_HPP_
#define _PROFE_HPP_
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>

using std::istream;
using std::ostream;
namespace is {
//!  Definición de la clase Profesor
class Profesor{
  //! \name Atributos privados de la clase Profesor
   private:
   	bool _coordinador; //!< coordinador 
//! \name Funciones o métodos publicos de la clase Profesor
	public:
//! \name Observadores: funciones de consulta de Profesor
	/*! 
		\brief   Funcion que si un profesor es coordinador o no
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Booleana
		\pre     Ninguna
		\post    Ninguna
	*/
	inline double getCoordinador() const{
		return _coordinador;
	}
	
	//! \name Funciones de modificacion de profesor
	/*! 
		\brief Funcion que asigna el valor "c" al atributo coordinador
		\note  Funcion inline
		\param c: nuevo valor de coordinador del profesor (tipo bool)
		\pre   Ninguna
		\post  (this->getCoordinador() == c)
		\sa setY()
	*/
	inline void setCoordinador(bool c){
		_coordinador=c;
		#ifndef NDEBUG
		assert( this->getCoordinador() == c ); 
		#endif
	}
	
    //! \name Operadores
	/*! 
		\brief     Operador de asignacion: operador que "copia" un profesor en otro
		\attention Se sobrecarga el operador de asignacion "="
		\note      Funcion inline
		\warning   Se requiere que las funciones de acceso get tengan el modificador const
		\param     p: objeto de tipo profesor pasado como referencia constante
		\pre       El profesor p debe ser diferente del profesor actual
		\post      this->getCoordinador() == p.getCoordinador()
	*/
	inline Profesor & operator=(is::Profesor const &p){
//Se comprueba que es distinto
		if (this != &p){
			setCoordinador(p.getCoordinador());
			#ifndef NDEBUG
			assert( this->getCoordinador() == p.getCoordinador() );    
			#endif
		}
		return *this;
	}
	/*! 
		\brief     Operador de igualdad: compara si un profesor es igual a otro
		\attention Se sobrecarga el operador de igualdad "=="
		\note      Funcion inline
		\param     p: objeto de tipo profesor pasado como referencia constante
		\pre       Ninguna
		\post      Ninguna
	*/
	inline bool operator == (is::Profesor const &p) const{
		if(this->getCoordinador() == p.getCoordinador())
			return true;
    return false;
	}
	/*! 
		\brief     Operador de desigualdad: compara si un profesor es diferente a otro
		\attention Se sobrecarga el operador de igualdad "!="
		\note      Funcion inline
		\param     p: objeto de tipo profesor pasado como referencia constante
		\pre       Ninguna
		\post      Ninguna
	*/
	inline bool operator != (is::Profesor const &p) const{
		if(this->getCoordinador() == p.getCoordinador())
			return false;
    return true;
	}
	//! \name Funciones lectura y escritura de la clase vertice
	/*! 
		\brief   Asigna a un profesor los atributos metidos por teclado
		\pre     Ninguna
		\post    Ninguna
	*/
	void leerProfesor();
}; // Fin de la definicion de la clase profesor
//! \name Funciones externas que utilizan argumentos del tipo vertice
    /*!
  		\brief     Sobrecarga del operador de salida o escritura "<<"
		\param     stream Flujo de salida
		\param     profesor pasado como referencia constante
		\pre       Ninguna
		\post      Ninguna
		\sa        operator>>()
    */
    ostream &operator<<(ostream &stream, is::Profesor const &profesor);

} // \brief Fin de namespace is.
//  _PROFE_HPP_
#endif
