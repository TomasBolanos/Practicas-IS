/*!
	\file principalGrafo.cpp
	\brief Programa principal de la practica 4 de IS
	\author Tomás Jesús Bolaños Campos
	\date 29/10/2018
	\version 1.0
*/
#include <iostream>
#include <string>
#include "alumno.hpp"
#include "profe.hpp"
#include "funcionesAuxiliares.hpp"
#include "macros.hpp"




/*! 
	\brief   Programa principal de la práctica 4
	\return  int
*/
int main(){
	is::Profesor p;
	is::Agenda a;
	std::string n;
	int opcion;
	int contador;
	int res;
	//bool ppw =p.registrarProfe();
	std::cout << BIYELLOW<<"--INICIO DE SESION--"<<std::endl;
	contador = p.leerProfesor();
	std::cout << BIYELLOW<<"--------------------"<<std::endl;
	if(contador == 2){
		//Menu de coordinador
		do{
		opcion = is::menu2();
		std::cout << CLEAR_SCREEN;
		PLACE(3,1);
		switch(opcion){
			case 0: 
					std::cout << INVERSE;
					std::cout << "Fin del programa" << std::endl;
					std::cout << RESET;
			break;
		   ///////////////////////////////////////////////////////////////////
			case 1: 
					std::cout << BIBLUE;
					std::cout << "[1] Cargar un fichero de Alumnos" << std::endl;
					std::cout << BIGREEN;
					
					is::cargarFich(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 2: 
					std::cout << BIBLUE;
					std::cout << "[2] Guardar un fichero de Alumnos" << std::endl;
					
					is::guardarFich(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 3: 
					std::cout << BIBLUE;
					std::cout << "[3] Añadir un alumno" << std::endl;
					is::Anadir(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 4: 
					std::cout << BIBLUE;
					std::cout << "[4] Modificar alumno" << std::endl;
					is::Modificar(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 5: 
					std::cout << BIBLUE;
					std::cout << "[5] Mostrar a todos los alumnos" << std::endl;
					is::MostrarTodos(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 6: 
					std::cout << BIBLUE;
					std::cout << "[6] Mostrar un solo alumno" << std::endl;
					is::MostrarUno(a);
					
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 7: 
					std::cout << BIBLUE;
					std::cout << "[7] Borrar a un alumno" << std::endl;
					is::Borrar(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 8: 
					std::cout << BIBLUE;
					std::cout << "[8] Guardar Copia de Seguridad" << std::endl;
					is::GuardarCopia(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 9: 
					std::cout << BIBLUE;
					std::cout << "[9] Cargar Copia de Seguridad" << std::endl;
					is::CargarCopia(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 10: 
					std::cout << BIBLUE;
					std::cout << "[10] Borrar la Agenda actual" << std::endl;
					is::BorrarTodo(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			default:
				std::cout << BIRED;
				std::cout << "Opción incorrecta ";
				std::cout << RESET;
				std::cout << "--> ";
			  	std::cout << ONIRED;
				std::cout << opcion << std::endl;
				std::cout << RESET;
     }
    if (opcion !=0)
    {
		PLACE(25,1);
		std::cout << "Pulse ";
		std::cout << BIGREEN;
		std::cout << "ENTER";
		std::cout << RESET;
		std::cout << " para mostrar el ";
		std::cout << INVERSE;
		std::cout << "menú"; 
		std::cout << RESET;
		std::cin.ignore();
		std::cout << CLEAR_SCREEN;
    }
	  }while(opcion!=0);
	}else if(contador == 1){
		//Menu de ayudante
		do{
		opcion = is::menu();
		std::cout << CLEAR_SCREEN;
		PLACE(3,1);
		switch(opcion){
			case 0: 
					std::cout << INVERSE;
					std::cout << "Fin del programa" << std::endl;
					std::cout << RESET;
			break;
		   ///////////////////////////////////////////////////////////////////
			case 1: 
					std::cout << BIBLUE;
					std::cout << "[1] Cargar un fichero de Alumnos" << std::endl;
					std::cout << BIGREEN;
					
					is::cargarFich(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 2: 
					std::cout << BIBLUE;
					std::cout << "[2] Guardar un fichero de Alumnos" << std::endl;
					
					is::guardarFich(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 3: 
					std::cout << BIBLUE;
					std::cout << "[3] Añadir un alumno" << std::endl;
					is::Anadir(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 4: 
					std::cout << BIBLUE;
					std::cout << "[4] Modificar alumno" << std::endl;
					is::Modificar(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 5: 
					std::cout << BIBLUE;
					std::cout << "[5] Mostrar a todos los alumnos" << std::endl;
					is::MostrarTodos(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 6: 
					std::cout << BIBLUE;
					std::cout << "[6] Mostrar un solo alumno" << std::endl;
					is::MostrarUno(a);
					
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 7: 
					std::cout << BIBLUE;
					std::cout << "[7] Borrar a un alumno" << std::endl;
					is::Borrar(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			case 8: 
					std::cout << BIBLUE;
					std::cout << "[8] Borrar la Agenda actual" << std::endl;
					is::BorrarTodo(a);
					break;
			//////////////////////////////////////////////////////////////////////////////
			default:
				std::cout << BIRED;
				std::cout << "Opción incorrecta ";
				std::cout << RESET;
				std::cout << "--> ";
			  	std::cout << ONIRED;
				std::cout << opcion << std::endl;
				std::cout << RESET;
     }
    if (opcion !=0)
    {
		PLACE(25,1);
		std::cout << "Pulse ";
		std::cout << BIGREEN;
		std::cout << "ENTER";
		std::cout << RESET;
		std::cout << " para mostrar el ";
		std::cout << INVERSE;
		std::cout << "menú"; 
		std::cout << RESET;
		std::cin.ignore();
		std::cout << CLEAR_SCREEN;
    }
	  }while(opcion!=0);
	}else if(contador == 0){
		std::cout<<BIBLUE<<"Usted no esta registrado\n¿Desea registrarse?\n(1-Si 0-No)"<<std::endl;
		cin >> res;
		if(res == 1){
			bool pp =p.registrarProfe();
			if(pp == true){
				std::cout << BIYELLOW<< "Ya esta usted registrado, vuelva a iniciar el programa"<<std::endl;
			 }else{
			 	std::cout << BIRED<< "Error"<<std::endl;
			 }
		 }else{
		 	std::cout << BIYELLOW<< "Esperamos vuelva pronto"<<std::endl;
		 }
	}else{
		std::cout << BIRED<< "Error de apertura de fichero"<<std::endl;
	}
	return 0;
}
