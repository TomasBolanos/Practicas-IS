/*!
  \file   funcionesAuxiliares.hpp
  \brief  Funciones auxiliares para el programa principal de la práctica 4
  \author Tomas Bolaños Campos
  \date  29/10/2018
*/
#ifndef _FuncionesAuxiliares_HPP_
#define _FuncionesAuxiliares_HPP_
#include "profe.hpp"
#include "agenda.hpp"
#include "alumno.hpp"

namespace is
{
	/*!
		\brief  Funcion Menu, maneja y enseña las opciones del menu		
	*/
	int menu();
	/*!
		\brief  Funcion Menu2, maneja y enseña las opciones del menu		
	*/
	int menu2();
	/*!
		\brief  Funcion MostrarTodos, para imprimir a los alumnos guardados		
	*/
	void MostrarTodos(Agenda a);
	/*!
		\brief  Funcion MostrarUno, funciona como buscador y muestra a un alumno o un grupo concreto	
	*/
	void MostrarUno(Agenda a);
	/*!
		\brief  Funcion Borrar, borra a un alumno concreto	
	*/
	void Borrar(Agenda &a);
	/*!
		\brief  Funcion Modificar, modifica los valores de un alumno concreto	
	*/
	void Modificar(Agenda &a);
	/*!
		\brief  Funcion Anadir, anade a un alumno a la Agenda
	*/
	void Anadir(Agenda &a);
	/*!
		\brief  Funcion GrabarFichero, Guarda la agenda en un fichero de alumnos
	*/	
	void guardarFich(Agenda &a);
	/*!
		\brief  Funcion GuardarCopia, Guarda copia de la agenda en un fichero de alumnos
	*/	
	void GuardarCopia(Agenda &a);
	/*!
		\brief  Funcion CargarFichero, Carga en la agenda un fichero de alumnos
	*/	
	void cargarFich(Agenda &a);
	/*!
		\brief  Funcion CargarCopia, Carga la copia en la agenda de un fichero de alumnos
	*/
	void CargarCopia(Agenda &a);
	/*!
		\brief  Funcion BorrarTodo, borra la agenda de alumnos
	*/
	void BorrarTodo(Agenda &a);
	
} // Fin del espacio de nombre de la asignatura: is
// Fin de _FuncionesAuxiliares_HPP_
#endif
