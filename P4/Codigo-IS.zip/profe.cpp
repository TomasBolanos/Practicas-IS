/*! 
   \file  profe.cpp
   \brief Fichero que contiene el código de las funciones de la clase Profesor
*/
#include <fstream>
#include <iostream>
#include <string>
#include <cctype>
#include <unistd.h>
#include <cstdlib>
#include <string.h>
#include <vector>
#include "profe.hpp"
#include "macros.hpp"
using namespace std;



