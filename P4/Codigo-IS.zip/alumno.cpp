/*! 
   \file  alumno.cpp
   \brief Fichero que contiene el código de las funciones de la clase Alumno
*/
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include "macros.hpp"
#include "alumno.hpp"
using namespace std;
void is::Alumno::leerAlumno(){
  	int n,n1,n2,n3;
	string c,c1,c2,c3,c4,c5;
	std::cout<<"Nombre : ";
	getline(cin, c, '\n');
	this->setNombre(c);
	usleep(100);
	std::cout<<"Apellidos : ";
	getline(cin, c1,'\n');
	this->setApellidos(c1);
	usleep(100);
	std::cout<<"(*) Dni : ";
	cin>>c2;
	this->setDni(c2);
	usleep(100);
	std::cout<<"Telefono : ";
	cin>>n;
	this->setTelefono(n);
	usleep(100);
	std::cout<<"(*) Correo : ";
	cin.ignore();
	getline(cin, c3, '\n');
	this->setCorreo(c3);
	usleep(100);
	std::cout<<"Domicilio : ";
	getline(cin, c4, '\n');
	this->setDomicilio(c4);
	usleep(100);
	std::cout<<"Fecha de Nacimiento : ";
	getline(cin, c5 ,'\n');
	this->setFechanacimiento(c5);
	usleep(100);
	std::cout<<"Curso mas alto en el que esta matriculado : ";
	cin>>n1;
	this->setCursoAlto(n1);
	std::cout<<"Equipo al que pertenece el alumno:\n(Si no pertenece a ninguno ponga 0) ";
	cin>>n2;
	this->setEquipo(n2);
	usleep(100);
	if(n2 != 0)
	{
		
		std::cout<<"¿Es lider del grupo?\n(1-Si 0-No)"<<std::endl;
		cin>>n3;
		if(n3 == 1)
			this->setLider(n3);
		else if(n3==0)
			this->setLider(n3);
		else
			this->setLider(0);
	}
	usleep(100);
	cin.ignore();

}


void is::Alumno::escribirAlumno(){

	std::cout<<"Nombre: "<<this->getNombre()<<" "<<this->getApellidos()<<std::endl;
	usleep(100);
	std::cout<<"DNI: "<<this->getDni()<<std::endl;
	usleep(100);
	std::cout<<"Telefono: "<<this->getTelefono()<<std::endl;
	usleep(100);
	std::cout<<"Correo: "<<this->getCorreo()<<std::endl;
	usleep(100);
	std::cout<<"Domicilio: "<<this->getDomicilio()<<std::endl;
	usleep(100);
	std::cout<<"Fecha de nacimiento: "<<this->getFechanacimiento()<<std::endl;
	usleep(100);
	std::cout<<"Curso mas alto en el que se encuentra matriculado: "<<this->getCursoAlto()<<std::endl;
	usleep(100);
	if(this->getEquipo() == 0){
		std::cout<<"Equipo: No asignado"<<std::endl;
		std::cout<< BIWHITE <<"Lider: No"<<std::endl;
	}else{
		std::cout<<BIPURPLE<<"Equipo: "<<this->getEquipo()<<std::endl;
		//Llamada a una funcion que mire el grupo y a los demas participantes para asi determinar el lider
		std::cout<<BIWHITE<<"Lider: "<<BIYELLOW<<this->getLider()<<std::endl;
	}

	
} 


