/*! 
   \file agenda.hpp
   \brief Fichero de la clase Agenda
   \author Tomas Jesus Bolaños Campos
*/
#ifndef _AGENDA_HPP_
#define _AGENDA_HPP_
#include <iostream>
#include <cassert>
#include <fstream>
#include <cmath>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <string.h>
//#include <stdio.h>
#include <vector>
#include <algorithm>
#include <unistd.h>
#include <assert.h>
#include <iomanip>
#include <ctime>
#include <sstream>
#include "alumno.hpp"
#include "macros.hpp"

using namespace std;
using std::istream;
using std::ostream;
namespace is {
typedef struct AuxliarAlumno{
 char nombre[200];
 char apellidos[200];
 char dni[10];
 int telefono;
 char correo[200];
 char domicilio[300];
 char fecha[200];
 int curso;
 int equipo;
 int lider;
}AUX;


//!  Definición de la clase Agenda
class Agenda{
  //! \name Atributos privados de la clase Agenda
   private:
    vector <Alumno> vec_;
//! \name Funciones o métodos publicos de la clase Agenda
	public:
	
	
	/*! 
		\brief   Función que devuelve el numero de alumnos de la Agenda
		\note    Función inline
		\return  Valor del atributo que representa el numero de alumnos
		\pre     Ninguna
		\post    Ninguna
	*/
	inline int getAlumnos() const{
		return vec_.size();
	}
	/*!
		\brief Indica si la Agenda está vacia o no
		\return  True en caso de vacio, false en caso contrario
	*/
	inline bool isEmpty(){
		if(vec_.empty() == true){//Si no hay Alumnos
			return true;
		}else{
			return false;
		}
	}
	/*!
		\brief Indica si la Agenda está vacia o no
		\return  True en caso de vacio, false en caso contrario
	*/
	inline int posicionAlumno(const is::Alumno &n){
		for(int i=0;i<getAlumnos();i++){
			if(n.getDni() == vec_[i].getDni() )
				return i;
		}
		return -1;
	}
	/*!
		\brief  Funcion que busca un alumno en la Agenda, para ver si existe
		\param n de tipo Alumno
		\pre La agenda debe existir
	*/
	bool existeAlumno(const is::Alumno &n){
		if(isEmpty() == true){
			return false;
		}
		#ifndef NDEBUG
		assert(isEmpty() == false);
		#endif
		for(int i=0; i<getAlumnos(); i++){
			if(vec_[i].getDni() == n.getDni()){//Si encontramos el alumno que buscamos
				return true;//Devolvemos true para indicar que se ha encontrado el Alumno
			}
		}
		return false;
	}
	/*!
		\brief  Funcion que busca un alumno en la Agenda, por DNI
		\param cadena de tipo string
		\pre La agenda debe existir
	*/
	Alumno buscarAlumnoDNI(string cadena){
		#ifndef NDEBUG
		assert(isEmpty() == false);
		#endif
		Alumno vacio;
		for(int i=0; i<getAlumnos(); i++){
			if(strcmp(cadena.c_str(),vec_[i].getDni().c_str()) == 0){
				return vec_[i];//Devolvemos true para indicar que se ha encontrado el Alumno
			}
		}
		return vacio;
	}
	/*!
		\brief  Funcion que busca un alumno en la Agenda, por apellido
		\param cadena de tipo string
		\pre La agenda debe existir
	*/
	Alumno buscarAlumnoApellidos(string cadena){
		#ifndef NDEBUG
		assert(isEmpty() == false);
		#endif
		Alumno vacio;
		for(int i=0; i<getAlumnos(); i++){
			if(strcmp(cadena.c_str(),vec_[i].getApellidos().c_str()) == 0){
				return vec_[i];//Devolvemos true para indicar que se ha encontrado el Alumno
			}
		}
		return vacio;
	}
	/*!
		\brief  Funcion que busca el grupo de  un alumno
		\param n de tipo Alumno
		\pre La agenda debe existir
	*/
	int buscarGrupo(const is::Alumno &n){
		#ifndef NDEBUG
		assert(existeAlumno(n) == true);
		#endif
		return n.getEquipo();
	}
	
	bool existeGrupo(int grupo){
		for(int i=0;i<getAlumnos();i++){
			if(grupo==vec_[i].getEquipo()){//Si encontramos el grupo del alumno
				return true;
			}
		}
		return false;
	}
	
	bool existeLider(int grupo){
		for(int i=0;i<getAlumnos();i++){
			if(grupo==vec_[i].getEquipo() and vec_[i].getLider() == 1){//Si encontramos el grupo del alumno
				return true;
			}
		}
		return false;
	}
	/*!
		\brief  Funcion que muestra los integrantes de un grupo
		\param grupo de tipo int
		\pre La agenda debe existir
	*/
	void escribirGrupo(int grupo){
		#ifndef NDEBUG
		assert(isEmpty() == false);
		#endif
		if(existeGrupo(grupo) == true){
			std::cout<<"INTEGRANTES:"<<std::endl;
			for(int i=0;i<getAlumnos();i++){
				if(grupo==vec_[i].getEquipo()){//Si encontramos el grupo del alumno
					if(vec_[i].getLider()==1){
						std::cout<<BIWHITE<<"Lider :"<<BIYELLOW<<vec_[i].getNombre()<<BIGREEN<<", "<<vec_[i].getApellidos()<<", "<<vec_[i].getCorreo()<<"."<<std::endl;
					}else{
					std::cout<<vec_[i].getNombre()<<", "<<vec_[i].getApellidos()<<", "<<vec_[i].getCorreo()<<"."<<std::endl;
					}
				}
			}
		}else{
			std::cout<<BIRED<<"Ese grupo no existe"<<std::endl;
		}
	}
	/*!
		\brief  Funcion que añade a un alumno
		\param n de tipo Alumno
		\pre La agenda debe existir
	*/
	void anadirAlumno(const is::Alumno &n){
		
		int old = getAlumnos();
		vec_.push_back(n);
		#ifndef NDEBUG
		assert(getAlumnos() == (old +1));
		#endif
	}
	/*!
		\brief  Funcion que borra a un alumno
		\param n de tipo Alumno
		\pre La agenda debe existir
	*/
	void borrarAlumno(const is::Alumno &n){
		#ifndef NDEBUG
		assert(existeAlumno(n) == true);
		#endif
		int old = getAlumnos();
		int i = posicionAlumno(n);
		vec_.erase(vec_.begin() + i);
		#ifndef NDEBUG
		assert(getAlumnos() == (old - 1));
		#endif
	}
	/*!
		\brief  Funcion que borra la agenda
		\pre La agenda debe existir
	*/
	void borrarAgenda(){
		vec_.clear();
	}
	/*!
		\brief  Funcion que muestra la lista de alumnos
		\param  Nnguno de tipo Alumno
		\pre La agenda debe existir
	*/
	void mostrarTodos(int opcion){
		#ifndef NDEBUG
		assert(isEmpty() == false);
		#endif
		ordenarAlfabeticamente(vec_,opcion);
		std::cout<<BIYELLOW<<"--DNI--"<<"--Apellidos--"<<"--Nombre--"<<"--Curso--"<<std::endl;
		for(int i=0; i<getAlumnos(); i++){
			std::cout<<vec_[i].getDni()<<" -- "<<vec_[i].getApellidos()<<"-- "<<vec_[i].getNombre()<<"-> "<<vec_[i].getCursoAlto()<<std::endl;
		}
		std::cout<<"<=========================>"<<std::endl;
	}
	
	void ordenarAlfabeticamente(vector <Alumno> &v,int opcion){
		Alumno aux;
		if(opcion ==1){
			for (unsigned int j=0; j<v.size()-1; j++)
			 	for (unsigned int i=0; i<v.size()-1; i++)
			 		if(v[i].getNombre()>v[i+1].getNombre())
			 		{
			 			aux=v[i];
			 			v[i]=v[i+1];
			 			v[i+1]=aux;
			 		}
		}
		if(opcion == 2){
			for (unsigned int j=0; j<v.size()-1; j++)
			 	for (unsigned int i=0; i<v.size()-1; i++)
			 		if(v[i].getApellidos()>v[i+1].getApellidos())
			 		{
			 			aux=v[i];
			 			v[i]=v[i+1];
			 			v[i+1]=aux;
			 		}
		}
		if(opcion == 3){
			for (unsigned int j=0; j<v.size()-1; j++)
			 	for (unsigned int i=0; i<v.size()-1; i++)
			 		if(v[i].getDni()>v[i+1].getDni())
			 		{
			 			aux=v[i];
			 			v[i]=v[i+1];
			 			v[i+1]=aux;
			 		}
		}
		if(opcion == 4){//Descendente
			for (unsigned int j=0; j<v.size()-1; j++)
			 	for (unsigned int i=0; i<v.size()-1; i++)
			 		if(v[i].getCursoAlto()<v[i+1].getCursoAlto())
			 		{
			 			aux=v[i];
			 			v[i]=v[i+1];
			 			v[i+1]=aux;
			 		}
		}
		if(opcion == 5){//Ascendente
			for (unsigned int j=0; j<v.size()-1; j++)
			 	for (unsigned int i=0; i<v.size()-1; i++)
			 		if(v[i].getCursoAlto()>v[i+1].getCursoAlto())
			 		{
			 			aux=v[i];
			 			v[i]=v[i+1];
			 			v[i+1]=aux;
			 		}
		}
	}
	
	bool camposVacios(const is::Alumno &n){
	//poner asserts
		if(n.getNombre().empty()==true || n.getDni().empty()==true || n.getApellidos().empty()==true || n.getTelefono()<=0 || n.getTelefono()> 999999999 || n.getCorreo().empty()==true || n.getDomicilio().empty()==true || n.getFechanacimiento().empty()==true || n.getCursoAlto()<=0 || n.getCursoAlto()>=6 || n.getEquipo()<0){
			return false;
		}
		return true;
	}

	bool comprobarCorreo(const is::Alumno &n){
			if(isEmpty() == true){
				return false;
			}
			#ifndef NDEBUG
			assert(isEmpty() == false);
			#endif
			for(int i=0; i<getAlumnos(); i++){
				if(vec_[i].getCorreo() == n.getCorreo()){//Si encontramos el vértice que buscamos
					return true;//Devolvemos true para indicar que se ha encontrado el Alumno
				}
			}
			return false;
	}
	
	
	
	void grabarFichero(){
		AUX aux;
		std::ofstream salida;
		salida.open("profesores.bin",ios::out | ios::binary);
			if(salida.is_open()){
			for(int i=0;i<getAlumnos();i++){
				strcpy(aux.nombre,vec_[i].getNombre().c_str());
				usleep(300);
				strcpy(aux.apellidos,vec_[i].getApellidos().c_str());
				strcpy(aux.dni,vec_[i].getDni().c_str());
				usleep(300);
				aux.telefono=vec_[i].getTelefono();
				usleep(300);
				strcpy(aux.domicilio,vec_[i].getDomicilio().c_str());
				strcpy(aux.correo,vec_[i].getCorreo().c_str());
				usleep(300);
				strcpy(aux.fecha,vec_[i].getFechanacimiento().c_str());
				usleep(300);
				aux.curso=vec_[i].getCursoAlto();
				usleep(300);
				aux.equipo=vec_[i].getEquipo();
				aux.lider=vec_[i].getLider();
				salida.write((const char*)&aux, sizeof(aux));
			}
			salida.close();
			}else{
			std::cout<<BIRED<<"Error abriendo el fichero"<<std::endl;
			}	
	}
	
	void grabarCopia(){
		int n=0;
		char nombrefich[200];
		std::time_t t = std::time(0);   // get time now
   		std::tm* now = std::localtime(&t);
   		//std::cout << (now->tm_year + 1900) << '-'<< (now->tm_mon + 1) << '-'<<  now->tm_mday<< "\n";
  		n=sprintf(nombrefich,"%d-%d-%d",(now->tm_year + 1900),(now->tm_mon + 1),now->tm_mday);
		n++;
		
		AUX aux;
		std::ofstream salida;
		salida.open(nombrefich,ios::out | ios::binary);
			if(salida.is_open()){
			for(int i=0;i<getAlumnos();i++){
				strcpy(aux.nombre,vec_[i].getNombre().c_str());
				usleep(300);
				strcpy(aux.apellidos,vec_[i].getApellidos().c_str());
				strcpy(aux.dni,vec_[i].getDni().c_str());
				usleep(300);
				aux.telefono=vec_[i].getTelefono();
				usleep(300);
				strcpy(aux.domicilio,vec_[i].getDomicilio().c_str());
				strcpy(aux.correo,vec_[i].getCorreo().c_str());
				usleep(300);
				strcpy(aux.fecha,vec_[i].getFechanacimiento().c_str());
				usleep(300);
				aux.curso=vec_[i].getCursoAlto();
				usleep(300);
				aux.equipo=vec_[i].getEquipo();
				aux.lider=vec_[i].getLider();
				salida.write((const char*)&aux, sizeof(aux));
			}
			salida.close();
			}else{
			std::cout<<BIRED<<"Error abriendo el fichero"<<std::endl;
			}
	}
	
	void cargarFichero(){
		int i;
		AUX aux;
		Alumno auxiliar;
		ifstream entrada;
		entrada.open("profesores.bin",ios::in | ios::binary);
		if(entrada.is_open()){
			i=0;
			while(!entrada.eof() and entrada.read((char*)&aux, sizeof(aux))){
				//Rellenar el vector
				string cadena(aux.nombre);
				auxiliar.setNombre(cadena);
				auxiliar.setApellidos(aux.apellidos);
				auxiliar.setDni(aux.dni);
				auxiliar.setCorreo(aux.correo);
				auxiliar.setTelefono(aux.telefono);
				auxiliar.setDomicilio(aux.domicilio);
				auxiliar.setFechanacimiento(aux.fecha);
				auxiliar.setCursoAlto(aux.curso);
				auxiliar.setEquipo(aux.equipo);
				auxiliar.setLider(aux.lider);
				anadirAlumno(auxiliar);
				i++;
			}
			//std::cout<<getAlumnos()<<"-"<<i<<std::endl;
		entrada.close();
		}else{
			std::cout<<BIRED<<"Error abriendo el fichero"<<std::endl;
			}
	}

	void cargarCopy(string nombrefich){
		int i;
		AUX aux;
		Alumno auxiliar;
		ifstream entrada;
		entrada.open(nombrefich.c_str(),ios::in | ios::binary);
		if(entrada.is_open()){
			i=0;
			while(!entrada.eof() and entrada.read((char*)&aux, sizeof(aux))){
				//Rellenar el vector
				string cadena(aux.nombre);
				auxiliar.setNombre(cadena);
				auxiliar.setApellidos(aux.apellidos);
				auxiliar.setDni(aux.dni);
				auxiliar.setCorreo(aux.correo);
				auxiliar.setTelefono(aux.telefono);
				auxiliar.setDomicilio(aux.domicilio);
				auxiliar.setFechanacimiento(aux.fecha);
				auxiliar.setCursoAlto(aux.curso);
				auxiliar.setEquipo(aux.equipo);
				auxiliar.setLider(aux.lider);
				anadirAlumno(auxiliar);
				i++;
			}
			//std::cout<<getAlumnos()<<"-"<<i<<std::endl;
		entrada.close();
		}else{
			std::cout<<BIRED<<"Error abriendo el fichero"<<std::endl;
			}
	}
	
};
}// \brief Fin de namespace is.
//  _AGENDA_HPP_
#endif
