/*! 
   \file profe.hpp
   \brief Fichero de la clase Profesor
   \author Tomas Jesus Bolaños Campos
*/
#ifndef _PROFE_HPP_
#define _PROFE_HPP_
#include <iostream>
#include <cassert>
#include <fstream>
#include <cmath>
#include <string>
#include <cstring>
#include "macros.hpp"

using namespace std;
using std::istream;
using std::ostream;
namespace is {
typedef struct Profesorado{
	char user[50];
	char passw[50];
	char coor[10];
}Profesorado;

//!  Definición de la clase Profesor
class Profesor{
  //! \name Atributos privados de la clase Profesor
   private:
   	bool _coordinador; //!< coordinador 
//! \name Funciones o métodos publicos de la clase Profesor
	public:
//! \name Observadores: funciones de consulta de Profesor
	/*! 
		\brief   Funcion que si un profesor es coordinador o no
		\warning Se utiliza el modificador const en la definicion de la funcion para poder definir el constructor de copia y el operador de asignacion "="
		\note    Funcion inline
		\return  Booleana
		\pre     Ninguna
		\post    Ninguna
	*/
	inline bool getCoordinador() const{
		return _coordinador;
	}
	
	//! \name Funciones de modificacion de profesor
	/*! 
		\brief Funcion que asigna el valor "c" al atributo coordinador
		\note  Funcion inline
		\param c: nuevo valor de coordinador del profesor (tipo bool)
		\pre   Ninguna
		\post  (this->getCoordinador() == c)
		\sa setY()
	*/
	inline void setCoordinador(bool c){
		_coordinador=c;
		#ifndef NDEBUG
		assert( this->getCoordinador() == c ); 
		#endif
	}
	
    //! \name Operadores
	/*! 
		\brief     Operador de asignacion: operador que "copia" un profesor en otro
		\attention Se sobrecarga el operador de asignacion "="
		\note      Funcion inline
		\warning   Se requiere que las funciones de acceso get tengan el modificador const
		\param     p: objeto de tipo profesor pasado como referencia constante
		\pre       El profesor p debe ser diferente del profesor actual
		\post      this->getCoordinador() == p.getCoordinador()
	*/
	inline Profesor & operator=(is::Profesor const &p){
//Se comprueba que es distinto
		if (this != &p){
			setCoordinador(p.getCoordinador());
			#ifndef NDEBUG
			assert( this->getCoordinador() == p.getCoordinador() );    
			#endif
		}
		return *this;
	}
	/*! 
		\brief     Operador de igualdad: compara si un profesor es igual a otro
		\attention Se sobrecarga el operador de igualdad "=="
		\note      Funcion inline
		\param     p: objeto de tipo profesor pasado como referencia constante
		\pre       Ninguna
		\post      Ninguna
	*/
	inline bool operator == (is::Profesor const &p) const{
		if(this->getCoordinador() == p.getCoordinador())
			return true;
    return false;
	}
	/*! 
		\brief     Operador de desigualdad: compara si un profesor es diferente a otro
		\attention Se sobrecarga el operador de igualdad "!="
		\note      Funcion inline
		\param     p: objeto de tipo profesor pasado como referencia constante
		\pre       Ninguna
		\post      Ninguna
	*/
	inline bool operator != (is::Profesor const &p) const{
		if(this->getCoordinador() == p.getCoordinador())
			return false;
    return true;
	}
	//! \name Funciones lectura y escritura de la clase vertice
	/*! 
		\brief   Asigna a un profesor los atributos metidos por teclado
		\pre     Ninguna
		\post    Ninguna
	*/
	int leerProfesor(){//ESTA FUNCION RECOGE: 0 SI NO SE HA LOGUEADO, 1 SI SE HA LOGUEADO PERO NO ES COORDINADOR, 2 SI SE HA LOGUEADO Y ES COORDINADOR
		 Profesorado p;
		 char usuario[50],password[50];
		 std::cout<<BIWHITE<<"Introduzca su usuario:"<<std::endl;
		 cin>>usuario;
		 std::cout<<BIWHITE<<"Introduzca su contraseña:"<<std::endl;
		 cin>>password;
		 ifstream entrada;
			entrada.open("usuarios.bin",ios::in | ios::binary);
			if(entrada.is_open()){
				while(!entrada.eof() and entrada.read((char*)&p, sizeof(p))){
					if(strcmp(usuario,p.user) == 0 and strcmp(password,p.passw) == 0){
						if(strcmp(p.coor,"true") == 0){
							entrada.close();
							return 2;
						}else if(strcmp(p.coor,"false") == 0){
							entrada.close();
							return 1;
						}else{
							entrada.close();
							return -1;
						}
					}
				}
			entrada.close();
			return 0;
			}else{
				std::cout<<BIRED<<"Error abriendo el fichero"<<std::endl;
				return -1;
			}
	}
	/*! 
		\brief   Registra un profe
		\pre     Ninguna
		\post    Ninguna
	*/
	bool registrarProfe(){
		Profesorado p;
		int n;
		std::ofstream salida;
		salida.open("usuarios.bin",ios::out | ios::binary);
			if(salida.is_open()){
				std::cout<<BIGREEN<<"Introduzca su usuario: ";
				 cin>>p.user;
				 std::cout<<BIGREEN<<"Introduzca su contraseña: ";
				 cin>>p.passw;
				 std::cout<<BIGREEN<<"¿Coordinador? \n(1-Si 0-No) ";
				 cin>>n;
				 if(n==1){
				 	strcpy(p.coor,"true");
				 	salida.write((const char*)&p, sizeof(p));
				 	salida.close();
				 	return true;
				 }else if(n==0){
				 	strcpy(p.coor,"false");
				 	salida.write((const char*)&p, sizeof(p));
				 	salida.close();
				 	return true;
				 }else{
				 	std::cout<<BIRED<<"Usted se equivocó pendejo "<<std::endl;
				 	salida.close();
				 	return false;
				 }
			}else{
			std::cout<<BIRED<<"Error abriendo el fichero"<<std::endl;
			return false;
			}
	}
}; // Fin de la definicion de la clase profesor


} // \brief Fin de namespace is.
//  _PROFE_HPP_
#endif
