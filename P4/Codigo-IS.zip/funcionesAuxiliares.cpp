/*!	
	\file  funcionesAuxiliares.cpp
	\brief Definición de las funciones auxiliares
	\author Tomas Jesus Bolaños Campos
	\date  29/10/2018
*/

#include <fstream>
#include <iostream>
#include <string>
#include <cctype>
#include <unistd.h>
#include <cstdlib>
#include <string.h>
#include <vector>
#include "funcionesAuxiliares.hpp"
#include "macros.hpp"


int is::menu()
{

	int opcion, posicion = 8;

	std::cout << CLEAR_SCREEN;


	PLACE(5,6);
	std::cout << BGREEN;
	std::cout << "Programa principial | Opciones del menú   ";
	std::cout << RESET;

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[1] " << IBLUE << "Cargar un fichero de Alumnos";

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[2] " << IBLUE << "Guardar un fichero de Alumnos";

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[3] " << IBLUE << "Añadir un alumno";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[4] " << IBLUE << "Modificar alumno";

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[5] " << IBLUE << "Mostrar a todos los alumnos";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[6] " << IBLUE << "Mostrar un solo alumno";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[7] " << IBLUE << "Borrar a un alumno";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[8] " << IBLUE << "Borrar la Agenda actual";

	PLACE(posicion++,6);
	std::cout << BIGREEN << "[0] " << IGREEN << "Salir";

	PLACE(posicion++,15);
	std::cout << IYELLOW;
	std::cout << "Opción: ";
	std::cout << RESET;

	// Se lee el número de opción
	std::cin >> opcion;

    // Se elimina el salto de línea del flujo de entrada
    std::cin.ignore();

    std::cout << CLEAR_SCREEN;

	return opcion;
}
//---------------------------------------------
int is::menu2()
{

	int opcion, posicion = 8;

	std::cout << CLEAR_SCREEN;


	PLACE(5,6);
	std::cout << BGREEN;
	std::cout << "Programa principial | Opciones del menú   ";
	std::cout << RESET;

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[1] " << IBLUE << "Cargar un fichero de Alumnos";

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[2] " << IBLUE << "Guardar un fichero de Alumnos";

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[3] " << IBLUE << "Añadir un alumno";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[4] " << IBLUE << "Modificar alumno";

	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[5] " << IBLUE << "Mostrar a todos los alumnos";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[6] " << IBLUE << "Mostrar un solo alumno";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[7] " << IBLUE << "Borrar a un alumno";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[8] " << IBLUE << "Guardar Copia de Seguridad";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[9] " << IBLUE << "Cargar Copia de Seguridad";
	
	PLACE(posicion++,6);
	std::cout << BIYELLOW << "[10] " << IBLUE << "Borrar la Agenda actual";

	PLACE(posicion++,6);
	std::cout << BIGREEN << "[0] " << IGREEN << "Salir";

	PLACE(posicion++,15);
	std::cout << IYELLOW;
	std::cout << "Opción: ";
	std::cout << RESET;

	// Se lee el número de opción
	std::cin >> opcion;

    // Se elimina el salto de línea del flujo de entrada
    std::cin.ignore();

    std::cout << CLEAR_SCREEN;

	return opcion;
}
//---------------------------------------------
void is::MostrarTodos(is::Agenda a)//TERMINADO
{
	int dato = -1;
	if(a.isEmpty() == true)
	{
		std::cout << BIRED << "La Agenda de Alumnos se encuentra vacía";
	}else{
		std::cout << BIGREEN << "¿Como desea que se le muestren los alumnos?" << std::endl << "( 1-Nombre 2-Apellidos 3-Dni 4-Curso Descendente 5-Curso Ascendente)"<<std::endl;
		std::cin >> dato;
		cin.ignore();
		std::cout<<BIYELLOW<<"<=========================>"<<std::endl;
		if(dato == 1 or dato == 2 or dato == 3 or dato == 4 or dato == 5){
			a.mostrarTodos(dato);
			std::cout << BIBLUE << "---- Finalizado con exito ----";
		}else
		{
			std::cout << BIRED << "La proxima vez introduzca una opcion valida";
		}		
		
	}

}
//----------------------------------------------
void is::MostrarUno(is::Agenda a)//TERMINADO
{
	int n,n1,grupo,res,c= 0,inf= 0;
	string cadena,cadena2;
	string cadena1 = "Vacio";
	
	//int  res;
	is::Alumno alumno;
	is::Alumno vacio;
	vector <Alumno> al;
	if(a.isEmpty() == true)
	{
		std::cout << BIRED << "La Agenda de Alumnos se encuentra vacía";
	}else{
		std::cout << BIBLUE << "¿Deseas buscar un alumno o un grupo?"<<std::endl<<"( 1 -Alumno  2 -Grupo)"<<std::endl;
		cin>> n;
		if(n == 1)
		{
			std::cout << BIGREEN << "¿Deseas buscar por Apellidos o Dni?"<<std::endl<<"( 1 -Apellidos  2 -Dni)"<<std::endl;
			cin>> n1;
			cin.ignore();
			if(n1 == 1)
			{
				std::cout << BIGREEN << "Introduzca los Apellidos"<<std::endl;
				std::getline(std::cin,cadena2,'\n');			
				do{
					if(a.isEmpty() == false){
						alumno = a.buscarAlumnoApellidos(cadena2);
						if(strcmp(vacio.getApellidos().c_str(),alumno.getApellidos().c_str()) == 0){
						//TERMINA LA BUSQUEDA
							inf=1;						
						}else{
						//ENCUENTRA
							al.push_back(alumno);
							a.borrarAlumno(alumno);
							//std::cout<<c<<" resultados"<<std::endl;
							c++;
						}
					}else//VECTOR VACIO
						inf=1;		
				}while(inf < 1 );
					if(c == 0){
						std::cout << BIRED << "---- No se han encontrado alumnos :/ ----";
					}else if(c == 1){
						std::cout<<BIPURPLE<<"---INFORMACION---"<<std::endl;
						al[0].escribirAlumno();
						std::cout << BIBLUE << "---- Finalizado con exito ----";
					}else{
						std::cout << BIGREEN << "---- Hay mas de un alumno con esos apellidos, busque por DNI ----";
					}
				
			}else if(n1 == 2)
			{
				//BuscarDni
				std::cout << BIGREEN << "Introduzca el dni"<<std::endl;
				cin >> cadena;
				alumno = a.buscarAlumnoDNI(cadena);
				res = strcmp(vacio.getDni().c_str(),alumno.getDni().c_str());
				if(res != 0){
						std::cout<<BIPURPLE<<"---INFORMACION---"<<std::endl;
						alumno.escribirAlumno();
						std::cout << BIBLUE << "---- Finalizado con exito ----";
						cin.ignore(256,'\n');
				}else{
						std::cout << BIYELLOW << "---- No se ha encontrado a nadie ----";
						cin.ignore(256,'\n');
				}
			}else{
				std::cout << BIRED << "La proxima vez introduzca una opcion valida";
			}
		}else if(n == 2)
		{
			std::cout<<BIBLUE<< "¿Desea buscar el grupo de un alumno o un grupo en concreto?"<<std::endl<<"(1 -Alumno  2 -Grupo)"<<std::endl;
			cin>>n1;
			if(n1==1){//BUSCA ALUMNO
				cout<<BIGREEN<<"Introduzca el DNI de dicho Alumno"<<std::endl;
				cin>>cadena;
				alumno=a.buscarAlumnoDNI(cadena);
				res = strcmp(cadena1.c_str(),alumno.getDni().c_str());				
				if(res!=0){
					//FUNCIONES GRUPO
					grupo=a.buscarGrupo(alumno);
					if(grupo != 0){
						std::cout<<BIPURPLE<<"---INFORMACION---"<<std::endl;
						alumno.escribirAlumno();
						std::cout<<BIPURPLE<<"-----------------"<<std::endl;
						a.escribirGrupo(grupo);
						std::cout << BIBLUE << "---- Finalizado con exito ----";
						cin.ignore();
					}else{
							std::cout<<BIYELLOW<< "Alumno no asignado a un grupo"<<std::endl;
							cin.ignore();
					}
				}else{
					std::cout<<BIRED<< "No se ha encontrado ningun alumno con ese DNI"<<std::endl;
					cin.ignore();
				}

			
			}else if(n1==2){//BUSCA AL GRUPO
				cout<<BIGREEN<<"Introduzca el grupo"<<std::endl;
				cin>>grupo;
				a.escribirGrupo(grupo);
				std::cout << BIBLUE << "---- Finalizado con exito ----";
				cin.ignore();
			}else{
				std::cout << BIRED << "La proxima vez introduzca una opcion valida";
			}
		}else
		{
			std::cout << BIRED << "La proxima vez introduzca una opcion valida";
		}
		
	}

}
//-----------------------------------------------
void is::Borrar(is::Agenda &a)//TERMINADO
{
	vector <Alumno> vector;
	if(a.isEmpty() == true)
	{
		std::cout << BIRED << "La Agenda de Alumnos se encuentra vacía";
	}else{
		int n = 0,res = 1;
		int i=0;
		string cadena2;
		string cadena;
		Alumno vacio;
		Alumno alumno;
		int c=0;
		std::cout << BIGREEN << "¿Deseas buscar por Apellidos o Dni?"<<std::endl<<"( 1 -Apellidos  2 -Dni)    ";
			cin>> n;
			cin.ignore();
			if(n == 1)
			{
				usleep(300);
				std::cout << BIGREEN << "Introduzca los Apellidos"<<std::endl;
				usleep(300);
				std::getline(std::cin,cadena2,'\n');
				usleep(300);
				//cin.ignore();
				//puts("Hola");
				do{
					if(a.isEmpty() == false){
						alumno = a.buscarAlumnoApellidos(cadena2);
						if(strcmp(vacio.getApellidos().c_str(),alumno.getApellidos().c_str()) == 0){
						//TERMINA LA BUSQUEDA
							i=1;						
						}else{
						//ENCUENTRA
							vector.push_back(alumno);
							a.borrarAlumno(alumno);
							//std::cout<<c<<" resultados"<<std::endl;
							c++;
						}
					}else
					//VECTOR VACIO
						i=1;		
				}while(i < 1 );
					if(c == 0){
						std::cout << BIRED << "---- No se han encontrado alumnos :/ ----";
					}else if(c == 1){				
						std::cout << BIBLUE << "---- Finalizado con exito ----";
					}else{
						for(unsigned int i=0;i<vector.size();i++){
							a.anadirAlumno(vector[i]);
						}
						std::cout << BIGREEN << "---- Hay mas de un alumno con esos apellidos, borre por DNI ----";
					}
			}else if(n == 2)
			{
				usleep(300);
				std::cout << BIGREEN << "Introduzca el dni del alumno"<<std::endl;
				usleep(300);
				cin >> cadena;
				usleep(300);
				alumno = a.buscarAlumnoDNI(cadena);
				usleep(300);
					res = strcmp(vacio.getDni().c_str(),alumno.getDni().c_str());
					usleep(300);
					if(res != 0){
						a.borrarAlumno(alumno);
						usleep(300);
						std::cout << BIBLUE << "---- Finalizado con exito ----";
						cin.ignore(256,'\n');
					}else{
						usleep(300);
						std::cout << BIYELLOW << "---- No se ha encontrado a nadie ----";
						cin.ignore(256,'\n');
					}
					usleep(300);				
			}else{
				std::cout << BIRED << "La proxima vez introduzca una opcion valida";
				cin.ignore(256,'\n');
			}
			
			usleep(300);
	}

}
//---------------------------------------------------
void is::Modificar(is::Agenda &a)//TERMINADO
{
	string cadena,n,ap,co,dom,f,d;
	Alumno vacio;
	Alumno aux;
	Alumno alumno;
	int c=0,res,t,cur,e,l;
	if(a.isEmpty() == true)
	{
		std::cout << BIRED << "La Agenda de Alumnos se encuentra vacía";
	}else{
		std::cout << BIGREEN << "Introduzca el dni del alumno"<<std::endl;
				usleep(300);
				cin >> cadena;
				cin.ignore();
				usleep(300);
				aux = a.buscarAlumnoDNI(cadena);
				usleep(300);
					res = strcmp(vacio.getDni().c_str(),aux.getDni().c_str());
					usleep(300);
					if(res != 0){
						std::cout << BIBLUE << "Alumno encontrado" << std::endl;
						std::cout << BIBLUE << "---- Pulse "<<BIGREEN<<"enter"<<BIBLUE<<" para seguir ----"<<std::endl;
						cin.ignore(256,'\n');
						alumno=aux;
						do{	
							std::cout << CLEAR_SCREEN;
							std::cout << BIYELLOW <<"Que campos desea cambiar del alumno?"<<std::endl;
							std::cout << BIBLUE <<"(1)-Nombre :"<< BIPURPLE << alumno.getNombre()<<std::endl;
							std::cout << BIBLUE <<"(2)-Apellidos :"<< BIPURPLE << alumno.getApellidos()<<std::endl;
							std::cout << BIBLUE <<"(3)-Dni :"<< BIPURPLE << alumno.getDni()<<std::endl;
							std::cout << BIBLUE <<"(4)-Telefono :"<< BIPURPLE << alumno.getTelefono()<<std::endl;
							std::cout << BIBLUE <<"(5)-Correo :"<< BIPURPLE << alumno.getCorreo()<<std::endl;
							std::cout << BIBLUE <<"(6)-Domicilio :"<< BIPURPLE << alumno.getDomicilio()<<std::endl;
							std::cout << BIBLUE <<"(7)-Fecha de Nacimiento :"<< BIPURPLE << alumno.getFechanacimiento()<<std::endl;
							std::cout << BIBLUE <<"(8)-Curso mas alto en el que esta matriculado :"<< BIPURPLE << alumno.getCursoAlto()<<std::endl;
							std::cout << BIBLUE <<"(9)-Equipo :"<< BIPURPLE << alumno.getEquipo()<<std::endl;
							std::cout << BIBLUE <<"(10)-Lider :"<< BIPURPLE << alumno.getLider()<<std::endl;						
							std::cout <<BIGREEN<<"Elija su opcion ( 0 para salir)"<<std::endl;
							cin>> c;
							cin.ignore();
							usleep(200);
							if(c == 1){
							std::cout << BIYELLOW <<"Introduzca el nuevo valor"<<std::endl;
								std::getline(std::cin, n, '\n');
								//std::cout<<n<<"----"<<std::endl;
								alumno.setNombre(n);
								//cin.ignore(256,'\n');
							}else if(c == 2){
							std::cout << BIYELLOW <<"Introduzca el nuevo valor"<<std::endl;
								std::getline(std::cin, ap, '\n');
								alumno.setApellidos(ap);
							//	cin.ignore();
							}else if(c == 3){
							std::cout << BIYELLOW <<"Introduzca el nuevo valor"<<std::endl;
								cin >> d;
								alumno.setDni(d);
							//	cin.ignore();
							}else if(c == 4){
							std::cout << BIYELLOW <<"Introduzca el nuevo valor"<<std::endl;
								cin >> t;
								alumno.setTelefono(t);
							//	cin.ignore();
							}else if(c==5){
							std::cout << BIYELLOW <<"Introduzca el nuevo valor"<<std::endl;
								cin >> co;
								alumno.setCorreo(co);
								//cin.ignore();
							}else if(c==7){
							std::cout << BIYELLOW <<"Introduzca el nuevo valor"<<std::endl;
								getline(cin, f, '\n');
								alumno.setFechanacimiento(f);
							//	cin.ignore();
							}else if(c ==6){
							std::cout << BIYELLOW <<"Introduzca el nuevo valor"<<std::endl;
								getline(cin, dom, '\n');
								alumno.setDomicilio(dom);
							//	cin.ignore();
							}else if(c ==8){
							std::cout << BIYELLOW <<"Introduzca el nuevo valor"<<std::endl;
								cin >> cur;
								alumno.setCursoAlto(cur);
							//	cin.ignore();
							}else if(c == 9){
							std::cout << BIYELLOW <<"Introduzca el nuevo valor"<<std::endl;
								cin >> e;
								alumno.setEquipo(e);
							
							}else if(c == 10){
							std::cout << BIYELLOW <<"Introduzca el nuevo valor"<<std::endl;
								cin >> l;
								alumno.setLider(l);
								//cin.ignore();
							}else{
								c=0;
							}
							cin.ignore();
						}while(c != 0);
						a.borrarAlumno(aux);
						a.anadirAlumno(alumno);
						std::cout << BIBLUE << "---- Finalizado con exito ----";
						//cin.ignore();
					}else{
						std::cout<<BIRED<<"No se ha encontrado a un alumno con ese DNI"<<std::endl;
					}
	}

}
//-----------------------------------------------------
void is::Anadir(is::Agenda &a)//TERMINADO
{
	is::Alumno alumno,alumno2;
	if(a.getAlumnos() == 150)
	{
		std::cout << BIRED << "La Agenda de Alumnos se encientra llena" << std::endl;
		std::cout << BIRED << "Debe vaciarla si quiere añadir de nuevo";
	}else{
		std::cout << BIBLUE << "Introduzca los datos necesarios:" << std::endl;
		alumno.leerAlumno();
		//Comprobacion de DNI y correo
		if(a.camposVacios(alumno)==true){
			if(a.existeAlumno(alumno) ==false && a.comprobarCorreo(alumno)==false){
				if(a.existeLider(alumno.getEquipo())){
					std::cout << BIRED << "---- El grupo indicado ya tiene lider ----";
				}else{
				a.anadirAlumno(alumno);
				usleep(100);
				std::cout << BIBLUE << "---- Finalizado con exito ----";
				}
			}else if(a.existeAlumno(alumno) ==true)
				std::cout << BIRED << "---- Ya existe un alumno con ese DNI ----";
			else if(a.comprobarCorreo(alumno)==true)
				std::cout << BIRED << "---- Ya existe un alumno con ese correo ----";
		}else{
			std::cout<< BIRED << "---- Algún campo esta vacio, debe rellenar todos los campos ----";
		}
	}
	
}




void is::guardarFich(is::Agenda &a){
	
	if(a.isEmpty() == false){
		a.grabarFichero();
		std::cout<<BIYELLOW<<"Se ha generado un fichero"<<BIBLUE<<" profesores.bin"<<std::endl;
		std::cout<<BIWHITE<<"---- Finalizado con exito ----"<<std::endl;
	}else{
		std::cout<<BIRED<<"La agenda se encuentra vacía"<<std::endl;
	}

}

void is::GuardarCopia(is::Agenda &a){
	if(a.isEmpty() == false){
		a.grabarCopia();
		std::cout<<BIYELLOW<<"Se ha generado una copia de seguridad"<<BIBLUE<<" "<<std::endl;
		std::cout<<BIWHITE<<"---- Finalizado con exito ----"<<std::endl;
	}else{
		std::cout<<BIRED<<"La agenda se encuentra vacía"<<std::endl;
	}
}

void is::cargarFich(is::Agenda &a){
	if(a.isEmpty() == true){
		a.cargarFichero();
		std::cout<<BIWHITE<<"---- Finalizado con exito ----"<<std::endl;
	}else{
		std::cout<<BIRED<<"La agenda se encuentra llena\n si desea cargar otra agenda debe borrar la actual"<<std::endl;
	}
}

void is::CargarCopia(is::Agenda &a){
	string cadena;
	if(a.isEmpty() == true){
		std::cout << BIBLUE << "Introduzca el nombre del fichero" << std::endl;
		cin >> cadena;
		a.cargarCopy(cadena);
		cin.ignore();
		std::cout<<BIWHITE<<"---- Finalizado con exito ----"<<std::endl;
	}else{
		std::cout<<BIRED<<"La agenda se encuentra llena\n si desea cargar otra agenda debe borrar la actual"<<std::endl;
	}
}

void is::BorrarTodo(is::Agenda &a){

	int c;
	if(a.isEmpty() == false){
		std::cout << BIWHITE <<"¿Esta seguro de que quiere borrar la agenda actual?\n( 1-Si 0-No)" << std::endl;
		cin >> c;
		if(c==1){
			a.borrarAgenda();
			std::cout<<BIBLUE<<"---- Finalizado con exito ----"<<std::endl;
		}else if(c==0){
			std::cout<<BIGREEN<<"---- Volvemos al menu ----"<<std::endl;
		}else{
			std::cout<<BIRED<<"- Opcion incorrecta -"<<std::endl;
		}
	}else{
		std::cout<<BIRED<<"La agenda se encuentra vacía"<<std::endl;
	}
	cin.ignore();
}

// Fin de _FuncionesAuxiliares_CPP_
