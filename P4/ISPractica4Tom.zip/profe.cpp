/*! 
   \file  profe.cpp
   \brief Fichero que contiene el código de las funciones de la clase Profesor
*/
#include <iostream>
#include <stdlib.h>
#include "profe.hpp"

void is::Profesor::leerProfesor(){
  bool n = false;
  int c;
  std::cout << "\n ¿Es usted coordinador?\n(1 para si )\n " << std::endl;
  std::cin >> c;
  if(c != 1)
  	this->setCoordinador(n);
  else
  {
  	n=true;
  	this->setCoordinador(n);
  }
}

// Sobrecarga del operador de salida
ostream & operator<<(ostream &stream, is::Profesor const &profesor){
  stream << "Coordinador: ";
  stream << profesor.getCoordinador()<<std::endl;

  return stream;
}


