/*! 
   \file agenda.hpp
   \brief Fichero de la clase Agenda
   \author Tomas Jesus Bolaños Campos
*/
#ifndef _AGENDA_HPP_
#define _AGENDA_HPP_
#include <iostream>
#include <cassert>
#include <cmath>
#include <string>
#include <vector>
#include <assert.h>
#include "alumno.hpp"

using std::istream;
using std::ostream;
namespace is {
//!  Definición de la clase Agenda
class Agenda{
  //! \name Atributos privados de la clase Agenda
   private:
    vector <Alumno> vec_;
//! \name Funciones o métodos publicos de la clase Agenda
	public:
	
	
	/*! 
		\brief   Función que devuelve el numero de alumnos de la Agenda
		\note    Función inline
		\return  Valor del atributo que representa el numero de alumnos
		\pre     Ninguna
		\post    Ninguna
	*/
	inline int getAlumnos() const{
		return vec_.size();
	}
	/*!
		\brief Indica si la Agenda está vacia o no
		\return  True en caso de vacio, false en caso contrario
	*/
	inline bool isEmpty(){
		if(vec_.empty() == true){//Si no hay Alumnos
			return true;
		}else{
			return false;
		}
	}
	/*!
		\brief Indica si la Agenda está vacia o no
		\return  True en caso de vacio, false en caso contrario
	*/
	inline int posicionAlumno(const is::Alumno &n){
		for(int i=0;i<getAlumnos();i++){
			if(n.getDni() == vec_[i].getDni() )
				return i;
		}
		return -1;
	}
	/*!
		\brief  Funcion que busca un alumno en la Agenda, para ver si existe
		\param n de tipo Alumno
		\pre La agenda debe existir
	*/
	bool existeAlumno(const is::Alumno &n){
		if(isEmpty() == true){
			return false;
		}
		#ifndef NDEBUG
		assert(isEmpty() == false);
		#endif
		for(int i=0; i<getAlumnos(); i++){
			if(vec_[i].getDni() == n.getDni()){//Si encontramos el vértice que buscamos
				return true;//Devolvemos true para indicar que se ha encontrado el Alumno
			}
		}
		return false;
	}
	/*!
		\brief  Funcion que busca un alumno en la Agenda, por DNI
		\param cadena de tipo string
		\pre La agenda debe existir
	*/
	Alumno buscarAlumnoDNI(string cadena){
		#ifndef NDEBUG
		assert(isEmpty() == false);
		#endif
		Alumno vacio;
		for(int i=0; i<getAlumnos(); i++){
			if(vec_[i].getDni() == cadena){//Si encontramos el vértice que buscamos
				return vec_[i];//Devolvemos true para indicar que se ha encontrado el Alumno
			}
		}
		return vacio;
	}
	/*!
		\brief  Funcion que busca un alumno en la Agenda, por apellido
		\param cadena de tipo string
		\pre La agenda debe existir
	*/
	Alumno buscarAlumnoApellidos(string cadena){
		#ifndef NDEBUG
		assert(isEmpty() == false);
		#endif
		Alumno vacio;
		for(int i=0; i<getAlumnos(); i++){
			if(vec_[i].getApellidos() == cadena){//Si encontramos el vértice que buscamos
				return vec_[i];//Devolvemos true para indicar que se ha encontrado el Alumno
			}
		}
		return vacio;
	}
	/*!
		\brief  Funcion que añade a un alumno
		\param n de tipo Alumno
		\pre La agenda debe existir
	*/
	void anadirAlumno(const is::Alumno &n){
		
		int old = getAlumnos();
		vec_.push_back(n);
		#ifndef NDEBUG
		assert(getAlumnos() == (old +1));
		#endif
	}
	/*!
		\brief  Funcion que borra a un alumno
		\param n de tipo Alumno
		\pre La agenda debe existir
	*/
	void borrarAlumno(const is::Alumno &n){
		#ifndef NDEBUG
		assert(existeAlumno(n) == true);
		#endif
		int old = getAlumnos();
		int i = posicionAlumno(n);
			vec_.erase(vec_.begin() + i);
		#ifndef NDEBUG
		assert(getAlumnos() == (old - 1));
		#endif
	}
	/*!
		\brief  Funcion que muestra la lista de alumnos
		\param  Nnguno de tipo Alumno
		\pre La agenda debe existir
	*/
	void mostrarTodos(){
		#ifndef NDEBUG
		assert(isEmpty() == false);
		#endif
		for(int i=0; i<getAlumnos(); i++){
			std::cout<<vec_[i].getDni()<<" -- "<<vec_[i].getApellidos()<<"-- "<<vec_[i].getNombre()<<"-> "<<vec_[i].getCorreo()<<std::endl;
		}
		std::cout<<"<=========================>"<<std::endl;
	}
};
}// \brief Fin de namespace is.
//  _AGENDA_HPP_
#endif
