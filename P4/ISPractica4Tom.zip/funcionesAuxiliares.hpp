/*!
  \file   funcionesAuxiliares.hpp
  \brief  Funciones auxiliares para el programa principal de la práctica 4
  \author Tomas Bolaños Campos
  \date  29/10/2018
*/
#ifndef _FuncionesAuxiliares_HPP_
#define _FuncionesAuxiliares_HPP_
#include "profe.hpp"
#include "agenda.hpp"
#include "alumno.hpp"

namespace is
{
	/*!
		\brief  Funcion Menu, maneja y enseña las opciones del menu		
	*/
	int menu();
	/*!
		\brief  Funcion MostrarTodos, para imprimir a los alumnos guardados		
	*/
	void MostrarTodos(Agenda a);
	/*!
		\brief  Funcion MostrarUno, funciona como buscador y muestra a un alumno o un grupo concreto	
	*/
	void MostrarUno(Agenda a);
	/*!
		\brief  Funcion Borrar, borra a un alumno concreto	
	*/
	void Borrar(Agenda &a);
	/*!
		\brief  Funcion Modificar, modifica los valores de un alumno concreto	
	*/
	void Modificar(Agenda &a);
	/*!
		\brief  Funcion Anadir, anade a un alumno a la Agenda
	*/
	void Anadir(Agenda &a);
	
	
	
	
} // Fin del espacio de nombre de la asignatura: is
// Fin de _FuncionesAuxiliares_HPP_
#endif
